﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MME.Global.QTM
{
    //1.确定归属（level，种子点）
    //2.着色显示

    class Voronoi
    {
    }
}
